<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/app.php';

header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store, max-age=0');

try {
    $expected = (string) (app_config()['cron_secret'] ?? '');
    $providedRaw = $_GET['key'] ?? $_SERVER['HTTP_X_CRON_KEY'] ?? '';
    $provided = is_string($providedRaw) ? $providedRaw : '';
    if (strlen($expected) < 32 || $provided === '' || !hash_equals($expected, $provided)) {
        http_response_code(403);
        echo "Akses ditolak.\n";
        exit;
    }
    if (!in_array(strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')), ['GET', 'POST'], true)) {
        header('Allow: GET, POST');
        http_response_code(405);
        echo "Metode HTTP tidak diizinkan.\n";
        exit;
    }

    $pdo = app_db();
    $now = date('Y-m-d H:i:s');
    $query = $pdo->prepare("SELECT r.id, r.title, r.category, r.reminder_at, r.has_time, r.note, u.display_name AS created_by_name
        FROM reminders r LEFT JOIN users u ON u.id = r.created_by
        WHERE r.status = 'pending' AND r.reminder_at <= :now AND r.due_notified_at IS NULL
        ORDER BY r.reminder_at ASC LIMIT 50");
    $query->execute([':now' => $now]);
    $reminders = $query->fetchAll();

    $claim = $pdo->prepare("UPDATE reminders SET due_notified_at = :claimed WHERE id = :id AND status = 'pending' AND due_notified_at IS NULL");
    $unclaim = $pdo->prepare('UPDATE reminders SET due_notified_at = NULL WHERE id = :id AND due_notified_at = :claimed');

    $sent = 0;
    $failed = 0;
    foreach ($reminders as $reminder) {
        $reminderId = (int) $reminder['id'];
        // Claim atomically before network I/O so overlapping cron runs never double-send.
        $claim->execute([':claimed' => $now, ':id' => $reminderId]);
        if ($claim->rowCount() !== 1) {
            continue;
        }
        // Bentuk pesannya sama dengan kabar yang dikirim saat pengingat dibuat/dikirim manual.
        // Sekarang dikirim ke semua penerima yang dipilih di Pengaturan → Notifikasi (multi-device).
        $message = app_reminder_message($reminder, '⏰ Pengingat rumah • waktunya dicek');
        $result = app_send_whatsapp_broadcast($message);
        if ($result['ok'] ?? false) {
            $sent += (int) ($result['sent'] ?? 1);
        } else {
            $unclaim->execute([':id' => $reminderId, ':claimed' => $now]);
            $failed++;
        }
    }

    // Laporan bulanan otomatis (diatur di Pengaturan → Bot WhatsApp).
    $monthlyNote = '';
    try {
        $dueReport = app_wa_monthly_due_period();
        if (
            $dueReport !== null
            && (string) app_setting('wa_monthly_last_key', '') !== $dueReport['key']
            && app_notification_slot($pdo, 'cron_monthly_lock:' . $dueReport['key'], 1, 300, time()) === 0
        ) {
            $report = app_wa_send_monthly_report($dueReport['key']);
            $monthlyNote = ' Laporan bulanan ' . $dueReport['label'] . ': ' . (int) $report['sent']
                . ' terkirim, ' . (int) $report['failed'] . ' gagal.';
        }
    } catch (Throwable $error) {
        error_log('[Laporan bulanan] ' . $error->getMessage());
        $monthlyNote = ' Laporan bulanan gagal diproses.';
    }

    echo "Pemeriksaan pengingat selesai. Terkirim: {$sent}; belum terkirim: {$failed}.{$monthlyNote}\n";
} catch (Throwable $error) {
    error_log('[Pengingat cron] ' . $error->getMessage());
    http_response_code(500);
    echo "Pemeriksaan reminder gagal. Periksa konfigurasi database dan server.\n";
}
